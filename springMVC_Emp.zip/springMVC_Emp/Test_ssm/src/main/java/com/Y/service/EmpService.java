package com.Y.service;

import com.Y.pojo.Emp;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface EmpService {
    //查询全部的书
    List<Emp> queryAllEmp(Map<String,Object>map);

    //删除员工
    int de_Emp(@Param("e_id") int e_id);

    //查询单个员工
    Emp emp_find(@Param("e_id") Integer e_id);
    //修改状态
    int up_status(@Param("e_status") int e_status,@Param("e_id") int e_id);

    //添加员工
    int add_emp(Emp emp);

    //修改员工
    int up_emp(Emp emp);
}
