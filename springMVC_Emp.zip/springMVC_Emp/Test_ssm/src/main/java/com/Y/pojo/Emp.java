package com.Y.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Emp  {

    private int e_id;
    private String e_name;
    private int e_sex;
    private double e_money;
    private String e_date;
    private String e_phone;
    private String e_img;
    private Integer e_status;


}
