package com.Y.service;

import com.Y.mapper.EmpMapper;
import com.Y.pojo.Emp;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("/EmpService")
public class EmpServiceImpl implements EmpService {

    //service调dao层：组合dao
    private EmpMapper empMapper;
    //set方法spring就可以托管了

    public void setEmpMapper(EmpMapper empMapper) {
        this.empMapper = empMapper;
    }

    @Override
    public List<Emp> queryAllEmp(Map<String, Object> map) {
        //当前页
        int currPage = 1;
        //如果当前页不等于null的话,就把map中的值赋给当前页
        if (null != map.get("currPage")){
            currPage = Integer.parseInt(map.get("currPage").toString());
        }
        //总页数
        int pageSize = Integer.parseInt(map.get("pageSize").toString());
        //起始页
        int startPage = (currPage-1)*pageSize;

        //总数量
        int totalCount = empMapper.selectCount(map);
        System.out.println(totalCount);
        //所有页数的数量
        int pageCount = (totalCount+pageSize-1)/pageSize;

        //上一页
        int prev = currPage<=1?currPage:currPage-1;
        //下一页
        int next = currPage>=pageCount?pageCount:currPage+1;

        //把数据添加到map中
        map.put("startPage",startPage);
        map.put("currPage",currPage);
        map.put("totalCount",totalCount);
        map.put("pageCount",pageCount);
        map.put("prev",prev);
        map.put("next",next);

        return empMapper.queryAllEmp(map);
    }

    @Override
    public int de_Emp(int e_id) {
        return empMapper.de_Emp(e_id);
    }

    @Override
    public Emp emp_find(Integer e_id) {
        return empMapper.emp_find(e_id);
    }

    @Override
    public int up_status(int e_status, int e_id) {
        return empMapper.up_status(e_status,e_id);
    }

    @Override
    public int add_emp(Emp emp) {
        return empMapper.add_emp(emp);
    }

    @Override
    public int up_emp(Emp emp) {
        return empMapper.up_emp(emp);
    }

}
