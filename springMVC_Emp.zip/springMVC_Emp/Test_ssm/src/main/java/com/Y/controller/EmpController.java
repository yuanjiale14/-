package com.Y.controller;

import com.Y.pojo.Emp;
import com.Y.service.EmpService;
import com.sun.mail.util.MailSSLSocketFactory;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("/Emp")
public class EmpController {
    //controller调service层
    @Autowired
    @Qualifier("EmpServiceImpl")
    private EmpService empService;
//    private BookService bookService=new BookServiceImpl();
    //查询全部的书籍，并且返回到一个书籍展示页面


    @RequestMapping(value = "/qEmps")
    public String queryEmp(Model model, HttpServletRequest request){
        String nameLike=request.getParameter("nameLike");
        Integer currPage = 1;
        if (null !=request.getParameter("currPage")){
            currPage = Integer.parseInt(request.getParameter("currPage"));
        }
        //创建map集合
        Map<String,Object> map = new HashMap<>();
        //把数据放进map中
        map.put("currPage",currPage);
        map.put("pageSize",4);
        map.put("nameLike",nameLike);

        List<Emp> Emps=empService.queryAllEmp(map);
        map.put("Emps",Emps);
        model.addAttribute("m",map);
        return "show";
    }


    @RequestMapping("/de_Emp/{e_id}")
    public  String de_Emp(Model model, @PathVariable("e_id") int e_id){
        Integer de_op=empService.de_Emp(e_id);
        if(de_op>0){
            System.out.println("删除成功");
        }
        return  "redirect:/Emp/qEmps";
    }

    /**
     * 上传
     * @param
     * @param request
     * @return
     * @throws IOException
     */
    @RequestMapping("/d")
    public String upload(Model model,HttpServletRequest request) throws IOException {
        System.out.println("进去了Add");
        Emp emp=new Emp();
        try {
            //路径
            String path = request.getSession().getServletContext().getRealPath("images");
            //工厂
            FileItemFactory f = new DiskFileItemFactory();
            //工人
            ServletFileUpload upload = new ServletFileUpload(f);
            //产品（文件项）
            List<FileItem> items = upload.parseRequest(request);
            //遍历
            for (FileItem item : items) {
                System.out.println(item);
                if (item.isFormField()) {//普通form元素
                    String fieldName = item.getFieldName();
                    //多个if判断，获取值
                    if ("e_name".equals(fieldName)) {
                        emp.setE_name(item.getString("utf-8"));
                        System.out.println(emp.getE_name());
                    }
                    if ("e_phone".equals(fieldName)) {
                        emp.setE_phone(item.getString("utf-8"));
                    }
                    if ("e_money".equals(fieldName)) {
                        emp.setE_money(Double.parseDouble(item.getString("utf-8")));
                    }
                    if ("e_sex".equals(fieldName)) {
                        emp.setE_sex(Integer.parseInt(item.getString("utf-8")));
                    }
                    if ("e_status".equals(fieldName)) {
                        emp.setE_status((Integer.parseInt(item.getString("utf-8"))));
                    }
                } else {//上传元素
                    String fileName = item.getName();
                    emp.setE_img(fileName);
                    //添加页面jq非空验证
                    File file = new File(path, fileName);
                    item.write(file);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  "show";
    }
    @RequestMapping("/to_add")
    public  String to_add(){
        return "add";
    }

    @RequestMapping("/to_up/{e_id}")
    public  String to_up(Model model,@PathVariable("e_id") Integer e_id){
        Emp emp=empService.emp_find(e_id);
        model.addAttribute("e",emp);
        return "up";
    }

    @RequestMapping("/up_status/{e_status}/{e_id}")
    public  String up_status(Model model,@PathVariable("e_status") Integer e_status,@PathVariable("e_id") Integer e_id){
        if(e_status==0){
         e_status=1;
        }else {
            e_status=0;
        }
        Integer up_status= empService.up_status(e_status,e_id);
        System.out.println("修改"+up_status);
        return "redirect:/Emp/qEmps";
    }

    @RequestMapping("/to_com")
    public String to_com(Model model,@PathVariable("qqcom") String qqcom){
        model.addAttribute("com",qqcom);
        return "com";
    }

    public void com(String po,String text) throws GeneralSecurityException, MessagingException, MessagingException {
        //实例化邮箱参数类，设置相关属性
        Properties prop = new Properties();
        prop.setProperty("mail.host", "smtp.qq.com");
        prop.setProperty("mail.transport.protocol", "smtp");
        prop.setProperty("mail.smtp.auth", "true");
        //关于邮箱的SSL加密 ，只有大厂需要，其他都不需要
        MailSSLSocketFactory sf = new MailSSLSocketFactory();
        sf.setTrustAllHosts(true);
        prop.put("mail.smtp.ssl.enable", "true");
        prop.put("mail.smtp.ssl.socketFactory", sf);
        //使用JavaMail发送邮件的五个步骤
//1.创建定义整个应用程序所需环境信息的Session对象 qq才有的！！！
        Session session = Session.getDefaultInstance(prop,new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("2951119113@qq.com",
                        "yblodvymprwqdgjj");
            }
        });
        //2.通过Session得到transport对象
        Transport transport = session.getTransport();
//3.使用邮箱用户名和授权码连接邮件服务器
        transport.connect("smtp.qq.com", "2951119113@qq.com", "yblodvymprwqdgjj");
        //4.创建邮件
        MimeMessage message = new MimeMessage(session);
        message.setSubject("这是一封java开发的邮件！！！！！！");//邮件主题
        message.setFrom(new InternetAddress("2951119113@qq.com"));//发件人
        message.setRecipient(Message.RecipientType.TO, new
                InternetAddress(po));//收件人
        message.setContent(text,"text/html;charset=utf-8");//邮箱的内容

//5.发送邮件
        transport.sendMessage(message, message.getAllRecipients());
//6.关闭连接
        transport.close();
    }
    @RequestMapping(value="/add_or_up/{op}/{e_id}",method = RequestMethod.POST)
    public String planSubmit(@PathVariable("e_id")String e_id,
                                   @RequestParam("e_name")String e_name,
                                   @RequestParam("e_sex")String e_sex,
                                   @RequestParam("e_money")String e_money,
                                   @RequestParam("e_phone")String e_phone,
                                   @RequestParam("e_status")String e_status,
                                   @RequestParam("file")MultipartFile multipartFile,
                                   @PathVariable("op")String op,
                                   HttpServletRequest request,Model model){
        ModelAndView mv = new ModelAndView();
//        System.out.println(op);

        String originalFilename;
        Emp emp = new Emp();
        if("1".equals(op)){
            emp.setE_id(Integer.parseInt(e_id));
            emp.setE_name(e_name);
            emp.setE_sex(Integer.valueOf(e_sex));
            emp.setE_date("NOW()");
            emp.setE_phone(e_phone);
            emp.setE_status(Integer.valueOf(e_status));
            System.out.println(emp.toString());
            if(multipartFile!=null && !multipartFile.isEmpty())
            {   //0，判断是否为空
                /**
                 * 对文件名进行操作防止文件重名
                 */
                //1，获取原始文件名
                originalFilename = multipartFile.getOriginalFilename();
                //2,截取源文件的文件名前缀,不带后缀
//            String fileNamePrefix = originalFilename.substring(0,originalFilename.lastIndexOf("."));
//            System.out.println("fileNamePrefix"+fileNamePrefix);
//            //3,加工处理文件名，原文件加上时间戳
////            String newFileNamePrefix  = fileNamePrefix + System.currentTimeMillis();
////            System.out.println("newFileNamePrefix"+newFileNamePrefix);
//
////            //4,得到新文件名
////            String newFileName = newFileNamePrefix + originalFilename.substring(originalFilename.lastIndexOf("."));
//
//            //5,构建文件对象
//            //路径
                String path = request.getSession().getServletContext().getRealPath("images");
                System.out.println("path"+path);
                File file = new File(path +originalFilename);
                //6,执行上传操作
                try {
                    multipartFile.transferTo(file);

                    emp.setE_img("images"+originalFilename);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            //设置调用Service层状态变量，1为添加记录成功，
            //0为不成功,-1为初始值
            int status = -1;
            try {
                status = empService.add_emp(emp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else if("2".equals(op)) {//修改
            emp.setE_id(Integer.parseInt(e_id));
            emp.setE_name(e_name);
            emp.setE_sex(Integer.valueOf(e_sex));
            emp.setE_phone(e_phone);
            emp.setE_status(Integer.valueOf(e_status));
            System.out.println(emp.toString());
            if(multipartFile!=null && !multipartFile.isEmpty())
            {   //0，判断是否为空
                /**
                 * 对文件名进行操作防止文件重名
                 */
                //1，获取原始文件名
                originalFilename = multipartFile.getOriginalFilename();
                //2,截取源文件的文件名前缀,不带后缀
//            String fileNamePrefix = originalFilename.substring(0,originalFilename.lastIndexOf("."));
//            System.out.println("fileNamePrefix"+fileNamePrefix);
//            //3,加工处理文件名，原文件加上时间戳
////            String newFileNamePrefix  = fileNamePrefix + System.currentTimeMillis();
////            System.out.println("newFileNamePrefix"+newFileNamePrefix);
//
////            //4,得到新文件名
////            String newFileName = newFileNamePrefix + originalFilename.substring(originalFilename.lastIndexOf("."));
//
//            //5,构建文件对象
//            //路径
                String path = request.getSession().getServletContext().getRealPath("images");
                System.out.println("path"+path);
                File file = new File(path +originalFilename);
                //6,执行上传操作
                try {
                    multipartFile.transferTo(file);

                    emp.setE_img("images"+originalFilename);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            //设置调用Service层状态变量，1为添加记录成功，
            //0为不成功,-1为初始值
            int status = -1;
            try {
                status = empService.up_emp(emp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return "redirect:/Emp/op";
    }

    @RequestMapping(value = "/op")
    public  void  op(HttpServletResponse response) throws IOException {
         response.sendRedirect("http://localhost:8080/Test_ssm_war_exploded/Emp/qEmps");
    }
}
